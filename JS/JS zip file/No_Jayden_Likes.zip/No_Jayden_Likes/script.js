function clickNumPlus(element) {
    var x = document.querySelector(element);
    console.log(element.previousElementSibling);
    // element.previousElementSibling.innerText++;
    x.innerText++;
}