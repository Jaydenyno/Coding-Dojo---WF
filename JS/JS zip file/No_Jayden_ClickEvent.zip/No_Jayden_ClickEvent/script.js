function likeButtonAlert() {
    alert("Ninja was liked");
}

function loginToLogoff(element) {
    element.innerText = "Logoff";
}

function removeAddDefinition(element) {
    element.remove();
}